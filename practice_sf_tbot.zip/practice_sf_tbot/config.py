TOKEN = '1511958499:AAHjheh3jZpCpSkYmxGln-y9jyB6-x0TM74'
CURRENCY_API = 'c699c1bde1dd304c11cd646a54220fb3'
#AVALIABLE CURRENCY
val = {
    'евро' : 'EUR',
    'рубль' : 'RUB',
    'доллар' : 'USD'
}
symbols = {
    'EUR' : '€',
    'RUB' : '₽',
    'USD' : '$'
}